#DetectUser.py
'''
module to detect the status of any user trying to join a meeting
user = [ID,IP Address, Device Address(from client software)]
it will use existing lists of participants ID as required -
1) part_c -> connected participants
2) part_r -> registered participants (in case meeting is private/booking based)
3) part_d -> disconnected participants who have joined once but now disconnected

return codes -
0 = Already connected with same account (cannot connect again)
1 = connecting first time (continue to connect to the meeting)
2 = user reconnecting (continue to connect to the meeting)
-1 = Already connected with same device (cannot connect again)
-2 = user not registered (cannot connect to private meeting)
'''

def DetectUser(user, part_c, part_r, part_d):
    if len(part_r):
        #check if meeting is private
        if user not in part_r:
            #user is not present in the registered participants list of the private meeting
            return -2
        else:
            if user in part_c:
                #user is in the registered list and is already connected in the meeting
                return 0
            elif user in part_d:
                #user is in the registered and is trying to reconnect
                return 2
            else:
                #user is in the registered and is trying to connect for the first time
                return 1
    #when meeting is not private
    elif user in part_c:
        #user is already connected to the meeting
        return 0
    elif user in part_d:
        #user connected once, but is not currently connected in the meeting
        return 2