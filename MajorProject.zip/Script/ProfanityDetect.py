#ProfanityDetect.py
'''
script to detect profanity in any text (string)
library used - profanity-police
'''
import sys
from profanity_police.checker import Checker

txt=sys.argv[1]
checker = Checker()
text = [{"text": txt}]
profanity_words_en = checker.check_swear_word(text, "en")

if len(profanity_words_en):
    print(1)
else:
    print(0)

